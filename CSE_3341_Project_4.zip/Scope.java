enum Scope {
    GLOBAL,
    IF,
    LOCAL,
    LOOP
}
